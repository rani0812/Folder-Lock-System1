# Folderlock-System-Using-Fingerprint.
 Implemented Java implementation of AES fingerprint algorithm for project - Developed efficient fingerprint authentication system as an alternative to password-based authentication - Improved security by utilizing biometric features unique to each individual - Eliminated risks associated with lost, forgotten, or compromised passwords.
